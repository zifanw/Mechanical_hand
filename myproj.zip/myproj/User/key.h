#ifndef __KEY_H
#define	__KEY_H
#include "stm32f10x.h"
int find_key_value (uint16_t row, uint16_t column);
#endif
