
//keyboard settings
char key11[1] = [' '];
char key12[3] = ['a','b','c'];
char key13[3] = ['d','e','f'];
char key21[3] = ['g','h','i'];
char key22[3] = ['j','k','l'];
char key23[3] = ['m','n','o'];
char key31[4] = ['p','q','r','s'];
char key32[3] = ['t','u','v'];
char key33[4] = ['w','x','y','z'];

