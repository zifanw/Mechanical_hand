# include "stm32f10x.h"
# include "string.h"
# define SUPPORTED_SENTENCES 1
# define SUPPORTED_WORDS 1


GPIO_InitTypeDef GPIO_InitStructure;
TIM_TimeBaseInitTypeDef	TIM_TimeBaseStructure;
TIM_OCInitTypeDef TIM_OCInitStructure;
void MCO_CONFIG (void);
void Delayus(int duration);
void KEY_CONFIG (void);
void MoveFinger(int command[5]);
int moto_dc;

int finger1;
int finger2;
int finger3;
int finger4;
int finger5;


// translate command into an approximate bending angle
void digitToAngle(int command[5]) {
	int temp;
	for (int i = 0; i < 5; i++) {
		temp = command[i];
    command[i] = 0;
    if (temp >= 4) {
      command[i] += 45;
      temp -= 4;
    }
    if (temp >= 2) {
      command[i] += 90;
      temp -= 2;
    }
    if (temp == 1) {
      command[i] += 180;
    }
  }
}
// translate angle into numbers for control
void angleToCycle(int command[5]) {
	for (int i = 0; i < 5; i++)
		command[i] = (0.5 + command[i] / 180)*125;
}


int main(void)
{	
	int min_cycle = 2500/20*0.5; //=62
	int max_cycle = 2500/20*2.5; //=312
	// Set up dictionary
	const char* sentences[SUPPORTED_SENTENCES];
	const char* words[SUPPORTED_WORDS];
	sentences[0] = "i love you";
	words[0] = "bye";

	// command coding
	const int number_commands[10][5] =
	{
	 {1, 6, 6, 6, 6},{2, 0, 3, 3, 3},{2, 0, 0, 3, 3},{0, 0, 0, 3, 3},{1, 0, 0, 0, 0},
	 {0, 0, 0, 0, 0},{1, 0, 0, 0, 3},{1, 0, 0, 3, 0},{1, 0, 3, 0, 0},{1, 3, 0, 0, 0}
	};
	const int alphabet_commands[26][5] =
	{
		{0, 3, 3, 3, 3},{3, 0, 0, 0, 0},{2, 6, 6, 6, 6},{2, 0, 3, 3, 3},{1, 3, 3, 3, 3},
		{2, 3, 0, 0, 0},{0, 0, 3, 3, 3},{0, 0, 0, 3, 3},{1, 3, 3, 3, 0},{1, 3, 3, 3, 0},
		{0, 0, 0, 3, 3},{0, 0, 3, 3, 3},{1, 7, 7, 7, 7},{1, 7, 7, 7, 7},{1, 6, 6, 6, 6},
		{0, 0, 1, 1, 1},{0, 1, 7, 7, 7},{2, 0, 0, 3, 3},{2, 3, 3, 3, 3},{0, 3, 3, 3, 3},
		{1, 0, 0, 3, 3},{1, 0, 0, 3, 3},{1, 0, 0, 0, 3},{3, 6, 3, 3, 3},{0, 3, 3, 3, 0},
		{1, 0, 3, 3, 3}
	};
	const int word_commands[SUPPORTED_WORDS][5] =
	{
		{2, 0, 0, 0, 0}
	};
	const int sentence_commands[SUPPORTED_SENTENCES][5] =
	{
		{0, 0, 3, 3, 0}
	};
	
	int command[5];
	
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO , ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 |  GPIO_Pin_7; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	TIM_TimeBaseStructure.TIM_Period = 1000; 
	TIM_TimeBaseStructure.TIM_Prescaler = 0;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
    
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = 500;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OC2PolarityConfig(TIM3, TIM_OCPolarity_High);
	TIM_OC1Init(TIM3, &TIM_OCInitStructure);

	TIM_OC1PreloadConfig(TIM3, TIM_OCPreload_Enable);
		
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = 200;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OC2PolarityConfig(TIM3, TIM_OCPolarity_High);
		
	TIM_OC2Init(TIM3, &TIM_OCInitStructure);
	TIM_OC2PreloadConfig(TIM3, TIM_OCPreload_Enable);

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7 |GPIO_Pin_8 |GPIO_Pin_9 ; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	TIM_SelectMasterSlaveMode(TIM3, TIM_MasterSlaveMode_Enable);
	TIM_SelectOutputTrigger(TIM3, TIM_TRGOSource_Update);

	TIM_TimeBaseStructure.TIM_Period = 2000; 

	TIM_TimeBaseStructure.TIM_Prescaler = 0;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);

	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;

	// Finger movement
	memcpy(command, number_commands[0], sizeof command);
	digitToAngle(command);
	angleToCycle(command);
  MoveFinger(command);
	
	MCO_CONFIG();
	KEY_CONFIG ();
  TIM_Cmd(TIM3, ENABLE); 
  TIM_Cmd(TIM4, ENABLE);
	
	
	while( 1 ) {
		// Finger movement
		memcpy(command, number_commands[1], sizeof command);
	  digitToAngle(command);
	  angleToCycle(command);
		MoveFinger(command);
		Delayus(5000000);
		
		memcpy(command, number_commands[2], sizeof command);
	  digitToAngle(command);
	  angleToCycle(command);
		MoveFinger(command);
		Delayus(5000000);
		
		memcpy(command, number_commands[3], sizeof command);
	  digitToAngle(command);
	  angleToCycle(command);
		MoveFinger(command);
		Delayus(5000000);
		
		memcpy(command, number_commands[4], sizeof command);
	  digitToAngle(command);
	  angleToCycle(command);
		MoveFinger(command);
		Delayus(5000000);
	}
}


void MCO_CONFIG (void)
{		
	/*
	 *  Task 1 ?Output SYSCLK via MCO.
	 */
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

}

void KEY_CONFIG (void)
{		
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
}
//void MoveFinger(int f1,int f2, int f3, int f4, int f5)
void MoveFinger(int command[5])
{
	finger1 = command[3];
	finger2 = command[4];
	finger3 = command[0];
	finger4 = command[2];
	finger5 = command[1];
	
	TIM_OCInitStructure.TIM_Pulse = finger1;   // finger 1 ring
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
  TIM_OC1Init(TIM4, &TIM_OCInitStructure);
  TIM_OC1PreloadConfig(TIM4, TIM_OCPreload_Enable);
		
			
	TIM_OCInitStructure.TIM_Pulse = finger2;   // finger 2 little
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
  TIM_OC2Init(TIM4, &TIM_OCInitStructure);
  TIM_OC2PreloadConfig(TIM4, TIM_OCPreload_Enable);
		
					
	TIM_OCInitStructure.TIM_Pulse = finger3;   // finger 3 thumb 
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
  TIM_OC3Init(TIM4, &TIM_OCInitStructure);
  TIM_OC3PreloadConfig(TIM4, TIM_OCPreload_Enable);
		
							
	TIM_OCInitStructure.TIM_Pulse = finger5;   // finger 4 middle
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OC4Init(TIM4, &TIM_OCInitStructure);
	TIM_OC4PreloadConfig(TIM4, TIM_OCPreload_Enable);
		
	TIM_SelectSlaveMode(TIM4, TIM_SlaveMode_Gated);
	TIM_SelectInputTrigger(TIM4, TIM_TS_ITR2);
}

void Delayus(int duration)
{
		while(duration--) 
		{
			int i=0x02;				
			while(i--)
			__asm("nop");
		}
}
